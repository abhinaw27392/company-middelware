'use strict';

var Promise = require('Bluebird');


function mapAssets(assets, inventories) {
    return assets;
}

module.exports = {
    mapAssets: Promise.method(mapAssets)
};