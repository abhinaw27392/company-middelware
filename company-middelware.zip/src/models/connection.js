'use strict';

var Sequelize = require('sequelize');

var connection = new Sequelize('leave_admin', 'root', 'root');

module.exports = connection;